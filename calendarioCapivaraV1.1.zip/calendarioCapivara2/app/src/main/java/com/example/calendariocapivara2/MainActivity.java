package com.example.calendariocapivara2;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        String[] alt= new String[]{"organismo das plantas vizinhas", "solo através de suas longas raízes", "chuva acumulada entre suas folhas", "seiva bruta das plantas hospedeiras", "comunidade que vive em seu interior"};
        ArrayList<String> alternativas = new ArrayList<>(Arrays.asList(alt));
        Questao q = new Questao("(ENEM - 2017)6888657",alternativas,"C","As epifitas são sim tipos de plantas que ficam no caule das árvores, mas não as parasitam");
        q.salvarBd();
//
//        Intent i = new Intent(this, TelaPratica.class);
//        startActivity(i);

        //String nome, String senha, int diaInicio, int anoInicio, ArrayList<Calendario> coisasParaFazer
//
//        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Usuario");
//        ref.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for(DataSnapshot d: snapshot.getChildren()){
//                    Usuario u = d.getValue(Usuario.class);
//
//                }
//            }
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });


//        Intent i = new Intent(this,TelaCalendario.class);
//            startActivity(i);
        //Toast.makeText(this, LocalDateTime.now().getDayOfWeek()+"",Toast.LENGTH_LONG).show();
    }
    public void telaLogin(View v){
        Intent i = new Intent(this,TelaLogin.class);
        startActivity(i);
    }
    public void telaCadastro(View v){

        Intent i = new Intent(this,TelaCadastro.class);
        startActivity(i);
    }


}