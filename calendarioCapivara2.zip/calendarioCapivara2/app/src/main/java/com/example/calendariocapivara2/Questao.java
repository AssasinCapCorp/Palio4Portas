package com.example.calendariocapivara2;

import android.graphics.Bitmap;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Questao {
    int idQ;
    String alternativa;
    String resposta;
    Bitmap imagem;

    public Questao(int idQ, String alternativa, String resposta, Bitmap imagem) {
        this.idQ = idQ;
        this.alternativa = alternativa;
        this.resposta = resposta;
        this.imagem = imagem;
    }

    public Questao() {
    }

    public int getIdQ() {
        return idQ;
    }

    public void setIdQ(int idQ) {
        this.idQ = idQ;
    }

    public String getAlternativa() {
        return alternativa;
    }

    public void setAlternativa(String alternativa) {
        this.alternativa = alternativa;
    }

    public String getResposta() {
        return resposta;
    }

    public void setResposta(String resposta) {
        this.resposta = resposta;
    }

    public Bitmap getImagem() {
        return imagem;
    }

    public void setImagem(Bitmap imagem) {
        this.imagem = imagem;
    }
    public void salvarBd(){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        ref.child("Questao").child(idQ+"").setValue(this);
    }
}
