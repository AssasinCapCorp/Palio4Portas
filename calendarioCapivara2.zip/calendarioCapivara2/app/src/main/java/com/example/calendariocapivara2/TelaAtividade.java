package com.example.calendariocapivara2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class TelaAtividade extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_atividade);
        getSupportActionBar().hide();
    }
    public void perfil(View v){
        Intent i = new Intent(this,TelaPerfil.class);
        startActivity(i);
    }
    public void materia(View v){
        Intent i = new Intent(this,TelaMaterias.class);
        startActivity(i);
    }
    public void questaoFoda(View c){
        Intent i = new Intent(this,TelaPratica.class);
        startActivity(i);
    }
}