package com.example.calendariocapivara2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TelaMaterias extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_materias);
        getSupportActionBar().hide();
    }
    public void mat(View v){
        listaDeTopicos("matematica");
    }
    public void cie(View c){
        listaDeTopicos("Natureza");
    }
    public void linguagens(View v){
        listaDeTopicos("linguagens");
    }
    public void humanas(View v){
        listaDeTopicos("humanas");
    }

    public void listaDeTopicos(String materia) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Topicos");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayList<Blocos> listaBlocos = new ArrayList<>();
                for (DataSnapshot d : snapshot.getChildren()) {
                    Blocos bloco = d.getValue(Blocos.class);
                    if (bloco.getMateria().equals(materia))
                        listaBlocos.add(bloco);
                }
                ListaDeAtividade.listBlocos = listaBlocos;
                ListaDeAtividade.materia = listaBlocos.get(0).getMateria();
                passarTela();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }


    public void passarTela(){
        Intent i = new Intent(this,ListaDeAtividade.class);
        startActivity(i);
    }
    public void home(View v){
        Intent i = new Intent(this,TelaAtividade.class);
        startActivity(i);
    }
    public void perfil(View v){
        Intent i = new Intent(this,TelaPerfil.class);
        startActivity(i);
    }
}